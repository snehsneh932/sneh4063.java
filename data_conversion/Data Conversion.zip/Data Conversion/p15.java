// 15. How to convert int to long

class IntToLong {
    public static void main(String[] args) {
        int intValue = 100;

        long longValue = intValue;

        System.out.println("Int value: " + intValue);
        System.out.println("Long value: " + longValue);
    }
}

/*
Output:
Int value: 100
Long value: 100
*/