// 19. How to convert char to int

class chartoint {
    public static void main(String[] args) {
        char ch = 'A';

        int intValue = ch;

        System.out.println("Char: " + ch);
        System.out.println("Int value (Unicode): " + intValue);
    }
}

/*
Output:
Char: A
Int value (Unicode): 65
 */