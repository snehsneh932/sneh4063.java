// 12. How to convert char to String

class CharToString {
    public static void main(String[] args) {
        char ch = 'A';

        String str2 = Character.toString(ch);
        System.out.println("Using Character.toString(): " + str2);

    }
}

/*
Output:
 Using Character.toString(): A
 */