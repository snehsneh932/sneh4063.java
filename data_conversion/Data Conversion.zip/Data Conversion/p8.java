// 8. How to convert double to String

class DoubleToString{
    public static void main(String[] args) {
        double number = 456.789;

        String str2 = Double.toString(number);
        System.out.println("Using Double.toString(): " + str2);

    }
}

/*
Output:
Using Double.toString(): 456.789
 */