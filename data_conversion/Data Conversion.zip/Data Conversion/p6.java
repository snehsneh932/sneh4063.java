// 6. How to convert float to String

class FloatToString {
    public static void main(String[] args) {
        float number = 123.45f;

        String str2 = Float.toString(number);
        System.out.println("Using Float.toString(): " + str2);
    }
}

/*
Output:
Using Float.toString(): 123.45
 */