// 16. How to convert long to int
class LongToInt {
    public static void main(String[] args) {
        long longValue = 100L;

        int intValue = (int) longValue;

        System.out.println("Long value: " + longValue);
        System.out.println("Int value: " + intValue);
    }
}

/*
Output:
Long value: 100
Int value: 100
 */