// 17. How to convert int to double

  class IntToDouble  {
    public static void main(String[] args) {
        int intValue = 42;
 
        double doubleValue = intValue;

        System.out.println("Int value: " + intValue);
        System.out.println("Double value: " + doubleValue);
    }
}

/*
Output:
Int value: 42
Double value: 42.0
 */