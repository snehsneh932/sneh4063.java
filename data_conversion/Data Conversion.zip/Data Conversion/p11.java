// 11. How to convert String to char
class StringToChar {
    public static void main(String[] args) {
        String str = "Hello";

        char ch = str.charAt(0);

        System.out.println("First character: " + ch);
    }
}

/*
Output:
First character: H
 */